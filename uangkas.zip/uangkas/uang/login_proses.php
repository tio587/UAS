<?php
include 'koneksi.php';

// Ambil data username dan password dari form login
$username = $_POST['username'];
$password = $_POST['password'];

// Pastikan username dan password tidak kosong
if (empty($username) || empty($password)) {
    die("Username atau password tidak boleh kosong.");
}

// Query untuk memeriksa apakah username ada dalam tabel admin
$sql = "SELECT * FROM admin WHERE username = '$username'";
$result = $conn->query($sql);

// Cek apakah query menghasilkan hasil
if ($result->num_rows > 0) {
    // Ambil data pengguna dari hasil query
    $row = $result->fetch_assoc();
    
    // Verifikasi password dengan password_verify() jika password di-hash
    if (password_verify($password, $row['password'])) {
        // Login berhasil
        echo "Selamat datang, " . $row['username'] . "!";
        // Redirect ke halaman admin atau dashboard setelah login berhasil
        // header("Location: dashboard.php");
    } else {
        // Jika password salah
        echo "Gagal Masuk Sebagai Admin: Password salah.";
    }
} else {
    // Jika username tidak ditemukan
    echo "Gagal Masuk Sebagai Admin: Username tidak ditemukan.";
}

// Menutup koneksi
$conn->close();
?>
