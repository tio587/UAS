<?php
$host = "localhost"; // atau alamat IP jika menggunakan server lain
$user = "root";      // username untuk login ke MySQL
$pass = "";          // password untuk login ke MySQL
$dbname = "database"; // nama database Anda

// Membuat koneksi ke database
$conn = mysqli_connect($host, $user, $pass, $dbname);

// Mengecek apakah koneksi berhasil
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
